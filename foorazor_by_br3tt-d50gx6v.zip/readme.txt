fooRazor v1.0.3 (DUI Config for foobar2000 by br3tt.deviantart.com)

Installation notes:
1. Copy the content of this folder to your foobar2000 user profile folder
   ==>If Normal install done, on Windows Seven, your foobar2000 user profile folder is C:\Users\<your_username>\AppData\Roaming\foobar2000\
   ==>If Portable install done, your foobar2000 user profile folder is your foobar2000 program folder, for example C:\My Programs\foobar2000\
2. Run foobar2000
3. Go to foobar Preferences: menu File>Preferences>Tools>WSH Panel Mod page, untick "Safe mode" option!
4. Go to foobar Preferences: menu File>Preferences>Display>Default User Interface> "click Import Theme button", then select the fooRazor .fth file, Apply/OK, it's done!

enjoy!

Tips: 
- double click on Play/Pause button = Stop button
- double click on Prev/Next button = Random play
- CoverFlow and Playlist panels have their own settings (collapsed toolbar on their top)

//EOF

